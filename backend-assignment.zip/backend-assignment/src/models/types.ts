import mongoose, { Schema, Document } from 'mongoose';

export const PRIORITY_SCORES = {
    EMERGENCY: 100,
    PREMIUM: 50,
    FOLLOW_UP: 30,
    ONLINE: 10,
    WALK_IN: 10
};

export interface IDoctor extends Document {
    name: string;
    specialty: string;
}

export interface ISlot extends Document {
    doctorId: mongoose.Types.ObjectId;
    startTime: Date;
    endTime: Date;
    hardLimit: number;
    currentBookingCount: number;
}

export interface IToken extends Document {
    patientName: string;
    type: 'ONLINE' | 'WALK_IN' | 'PREMIUM' | 'FOLLOW_UP' | 'EMERGENCY';
    status: 'PENDING' | 'COMPLETED' | 'CANCELLED';
    priorityScore: number;
    slotId: mongoose.Types.ObjectId | null;
    requestTime: Date;
}

const DoctorSchema: Schema = new Schema({
    name: { type: String, required: true },
    specialty: { type: String, required: true }
});

const SlotSchema: Schema = new Schema({
    doctorId: { type: Schema.Types.ObjectId, ref: 'Doctor', required: true },
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
    hardLimit: { type: Number, required: true },
    currentBookingCount: { type: Number, default: 0 }
});

const TokenSchema: Schema = new Schema({
    patientName: { type: String, required: true },
    type: {
        type: String,
        enum: ['ONLINE', 'WALK_IN', 'PREMIUM', 'FOLLOW_UP', 'EMERGENCY'],
        required: true
    },
    status: {
        type: String,
        enum: ['PENDING', 'COMPLETED', 'CANCELLED'],
        default: 'PENDING'
    },
    priorityScore: { type: Number, required: true },
    slotId: { type: Schema.Types.ObjectId, ref: 'Slot', default: null },
    requestTime: { type: Date, default: Date.now }
});

export const Doctor = mongoose.model<IDoctor>('Doctor', DoctorSchema);
export const Slot = mongoose.model<ISlot>('Slot', SlotSchema);
export const Token = mongoose.model<IToken>('Token', TokenSchema);
