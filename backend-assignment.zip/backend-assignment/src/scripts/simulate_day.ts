import { initializeDatabase } from '../database/db.js';
import { Doctor, Slot, Token } from '../models/types.js';
import { allocateToken, handleCancellation } from '../core/allocator.js';
import mongoose from 'mongoose';

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

const simulateDay = async () => {
    console.log('--- STARTING OPD SIMULATION ---');
    await initializeDatabase();

    await Doctor.deleteMany({});
    await Slot.deleteMany({});
    await Token.deleteMany({});

    console.log('\n[Setup] Creating Doctors...');
    const doc1 = await Doctor.create({ name: 'Dr. House', specialty: 'Diagnostics' });
    const doc2 = await Doctor.create({ name: 'Dr. Strange', specialty: 'Surgery' });
    const doc3 = await Doctor.create({ name: 'Dr. Who', specialty: 'General' });
    console.log(`Created ${doc1.name}, ${doc2.name}, ${doc3.name}`);

    console.log('\n[Setup] Creating Slots...');
    // Doc 1: Limited capacity
    const slot1 = await Slot.create({
        doctorId: doc1._id,
        startTime: new Date().setHours(9, 0, 0, 0),
        endTime: new Date().setHours(10, 0, 0, 0),
        hardLimit: 2
    });

    // Doc 2: More capacity
    const slot2 = await Slot.create({
        doctorId: doc2._id,
        startTime: new Date().setHours(10, 0, 0, 0),
        endTime: new Date().setHours(11, 0, 0, 0),
        hardLimit: 5
    });

    // Doc 3: Afternoon
    await Slot.create({
        doctorId: doc3._id,
        startTime: new Date().setHours(14, 0, 0, 0),
        endTime: new Date().setHours(15, 0, 0, 0),
        hardLimit: 3
    });

    console.log('\n--- SCENARIO 1: Normal Booking (Dr. House) ---');
    const p1 = await Token.create({ patientName: 'Alice (Online)', type: 'ONLINE', priorityScore: 10 });
    console.log(`Request 1: ${p1.patientName} - ${await allocateToken(p1._id as unknown as string)}`);

    const p2 = await Token.create({ patientName: 'Bob (Walk-in)', type: 'WALK_IN', priorityScore: 10 });
    console.log(`Request 2: ${p2.patientName} - ${await allocateToken(p2._id as unknown as string)}`);

    console.log('\n--- SCENARIO 2: Overflow & Bumping (Dr. House) ---');
    // Fill up Doc 1
    const p3 = await Token.create({ patientName: 'Charlie (Low Prio)', type: 'ONLINE', priorityScore: 10 });
    console.log(`Request 3: ${p3.patientName} - ${await allocateToken(p3._id as unknown as string)} (Expected: Waitlist)`);

    // Emergency bump
    const p4 = await Token.create({ patientName: 'DAVE (EMERGENCY)', type: 'EMERGENCY', priorityScore: 100 });
    console.log(`Request 4: ${p4.patientName} - ${await allocateToken(p4._id as unknown as string)} (Expected: Allocation via bump)`);

    console.log('\n--- SCENARIO 3: Booking Other Doctors ---');
    const p5 = await Token.create({ patientName: 'Eve (Premium)', type: 'PREMIUM', priorityScore: 50 });

    console.log(`Request 5: ${p5.patientName} - ${await allocateToken(p5._id as unknown as string)}`);

    console.log('\n--- FINAL STATUS ---');
    const allTokens = await Token.find({}).populate('slotId');
    allTokens.forEach(t => {
        // @ts-ignore
        const slotInfo = t.slotId ? `Allocated (Slot ID: ${t.slotId._id})` : 'Waiting';
        console.log(`- ${t.patientName} [${t.type}] : ${t.status} -> ${slotInfo}`);
    });

    console.log('\n[Cleanup] Closing DB connection.');
    await mongoose.connection.close();
};

simulateDay();
