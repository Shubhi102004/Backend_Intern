import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { initializeDatabase } from './database/db.js';
import { createDoctor, createSlot, getSchedule, bookToken, cancelToken } from './controllers/api.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

initializeDatabase();

app.get('/', (req, res) => {
    res.send('OPD Token Allocation Engine API is running');
});

app.post('/api/doctors', createDoctor);
app.post('/api/slots', createSlot);
app.get('/api/doctors/:doctorId/schedule', getSchedule);
app.post('/api/tokens/book', bookToken);
app.post('/api/tokens/cancel', cancelToken);

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
