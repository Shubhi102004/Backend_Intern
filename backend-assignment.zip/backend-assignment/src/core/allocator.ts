import { Token, Slot, ISlot, IToken, PRIORITY_SCORES } from '../models/types.js';
import mongoose from 'mongoose';

export const getPriorityScore = (type: string): number => {
    return PRIORITY_SCORES[type as keyof typeof PRIORITY_SCORES] || 0;
};

export const allocateToken = async (tokenId: string): Promise<string> => {
    const token = await Token.findById(tokenId);
    if (!token) throw new Error('Token not found');

    const slots = await Slot.find({}).sort({ startTime: 1 });

    for (const slot of slots) {
        if (slot.currentBookingCount < slot.hardLimit) {
            return await finalizeAllocation(token, slot);
        } else {
            const bumpableToken = await findBumpableToken(slot._id as mongoose.Types.ObjectId, token.priorityScore);
            if (bumpableToken) {
                console.log(`Bumping token ${bumpableToken._id} for high priority token ${token._id}`);

                bumpableToken.slotId = null;
                bumpableToken.status = 'PENDING';
                await bumpableToken.save();
                slot.currentBookingCount -= 1;

                return await finalizeAllocation(token, slot);
            }
        }
    }

    return 'No slot available (Waitlisted)';
};

const finalizeAllocation = async (token: IToken, slot: ISlot): Promise<string> => {
    token.slotId = slot._id as mongoose.Types.ObjectId;
    token.status = 'PENDING';
    token.priorityScore = getPriorityScore(token.type);

    slot.currentBookingCount += 1;

    await token.save();
    await slot.save();
    return `Allocated to slot ${slot.startTime}`;
}

const findBumpableToken = async (slotId: mongoose.Types.ObjectId, candidateScore: number): Promise<IToken | null> => {
    const tokensInSlot = await Token.find({ slotId: slotId, status: { $ne: 'CANCELLED' } }).sort({ priorityScore: 1 });

    if (tokensInSlot.length > 0) {
        const lowestToken = tokensInSlot[0];
        if (lowestToken.priorityScore < candidateScore) {
            return lowestToken;
        }
    }
    return null;
};

export const handleCancellation = async (slotId: string) => {
    const slot = await Slot.findById(slotId);
    if (!slot) return;

    if (slot.currentBookingCount > 0) {
        slot.currentBookingCount -= 1;
        await slot.save();
    }
};
