import { Request, Response } from 'express';
import { Doctor, Slot, Token } from '../models/types.js';
import { allocateToken, handleCancellation } from '../core/allocator.js';

export const createDoctor = async (req: Request, res: Response) => {
    try {
        const { name, specialty } = req.body;
        const doctor = await Doctor.create({ name, specialty });
        res.status(201).json(doctor);
    } catch (err: any) {
        res.status(500).json({ error: err.message });
    }
};

export const createSlot = async (req: Request, res: Response) => {
    try {
        const { doctorId, startTime, endTime, hardLimit } = req.body;
        const slot = await Slot.create({
            doctorId,
            startTime: new Date(startTime),
            endTime: new Date(endTime),
            hardLimit
        });
        res.status(201).json(slot);
    } catch (err: any) {
        res.status(500).json({ error: err.message });
    }
};

export const getSchedule = async (req: Request, res: Response) => {
    try {
        const { doctorId } = req.params;
        const slots = await Slot.find({ doctorId }).populate('doctorId');
        const schedule = await Promise.all(slots.map(async (slot) => {
            const tokens = await Token.find({ slotId: slot._id });
            return { ...slot.toObject(), tokens };
        }));
        res.json(schedule);
    } catch (err: any) {
        res.status(500).json({ error: err.message });
    }
};

export const bookToken = async (req: Request, res: Response) => {
    try {
        const { patientName, type } = req.body;
        const token = await Token.create({
            patientName,
            type,
            priorityScore: 0
        });

        const result = await allocateToken(token._id as unknown as string);

        const updatedToken = await Token.findById(token._id);

        res.status(200).json({
            message: result,
            token: updatedToken
        });

    } catch (err: any) {
        res.status(500).json({ error: err.message });
    }
};

export const cancelToken = async (req: Request, res: Response) => {
    try {
        const { tokenId } = req.body;
        const token = await Token.findById(tokenId);
        if (!token) {
            res.status(404).json({ error: "Token not found" });
            return;
        }

        if (token.slotId) {
            await handleCancellation(token.slotId.toString());
        }

        token.status = 'CANCELLED';
        token.slotId = null;
        await token.save();

        res.json({ message: 'Token cancelled' });
    } catch (err: any) {
        res.status(500).json({ error: err.message });
    }
};
